import os, time, zipfile, hashlib, requests
from typing import Dict
from dotenv import load_dotenv

EXCLUDE_DIRS = {".venv", "__pycache__", ".git", "dist", "build", ".pytest_cache", ".mypy_cache"}
REQUIRED_KEYS = {"version", "zip_url"}

def validate_manifest(m: Dict) -> str:
    """Return empty string if ok, else error message."""
    if not isinstance(m, dict):
        return "Манифест не является JSON-объектом"
    missing = REQUIRED_KEYS - set(m.keys())
    if missing:
        return "Отсутствуют ключи: " + ", ".join(sorted(missing))
    v = str(m.get("version", "")).strip()
    z = str(m.get("zip_url", "")).strip()
    if not v or not z:
        return "Поля version/zip_url пустые"
    sha = str(m.get("sha256", "")).strip()
    if sha and len(sha) != 64:
        return "sha256 должен быть 64-символьной hex-строкой"
    if not (z.startswith("http://") or z.startswith("https://")):
        return "zip_url должен быть по HTTP(S)"
    return ""

def read_local_version(root: str) -> str:
    try:
        return open(os.path.join(root,"VERSION"),"r",encoding="utf-8").read().strip()
    except FileNotFoundError:
        return "0.0.0"

def fetch_manifest(url: str) -> Dict:
    r = requests.get(url, timeout=15)
    r.raise_for_status()
    return r.json()

def version_tuple(v: str):
    try:
        return tuple(int(x) for x in v.split(".") if x.isdigit())
    except Exception:
        return (0,0,0)

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path,"rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def download_file(url: str, dest: str):
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        with open(dest,"wb") as f:
            for ch in r.iter_content(8192):
                if ch: f.write(ch)

def backup_current(root: str) -> str:
    bdir = os.path.join(root,"backups"); os.makedirs(bdir, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S"); target = os.path.join(bdir, f"backup-{ts}.zip")
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as zf:
        for folder,_,files in os.walk(root):
            rel_folder = os.path.relpath(folder, root)
            if rel_folder.split(os.sep)[0] in EXCLUDE_DIRS: continue
            for name in files:
                p = os.path.join(folder,name); rel = os.path.relpath(p, root)
                if rel.split(os.sep)[0] in EXCLUDE_DIRS: continue
                zf.write(p, rel)
    return target

def apply_zip_over(root: str, zip_path: str):
    with zipfile.ZipFile(zip_path,"r") as zf:
        for member in zf.infolist():
            if member.is_dir(): continue
            rel = member.filename.replace("\\","/"); top = rel.split("/")[0]
            if top in EXCLUDE_DIRS: continue
            if rel.startswith("samples/"): continue
            out_path = os.path.join(root, rel)
            os.makedirs(os.path.dirname(out_path), exist_ok=True)
            with zf.open(member,"r") as src, open(out_path,"wb") as dst:
                dst.write(src.read())

def update_from_manifest(root: str) -> str:
    load_dotenv()
    url = os.getenv("UPDATE_MANIFEST_URL","").strip()
    if not url: return "UPDATE_MANIFEST_URL не задан в .env"
    local_ver = read_local_version(root)
    try:
        m = fetch_manifest(url)
    except Exception as e:
        return f"Не удалось получить манифест: {e}"
    err = validate_manifest(m)
    if err:
        return f"Манифест некорректен: {err}"
    remote_ver = str(m.get("version","")).strip()
    zip_url = str(m.get("zip_url","")).strip()
    sha = str(m.get("sha256","")).strip()
    notes = str(m.get("notes",""))
    if version_tuple(remote_ver) <= version_tuple(local_ver):
        return f"Обновление не требуется. Текущая версия {local_ver}, удалённая {remote_ver}."
    tmp_zip = os.path.join(root,"_update.zip")
    try: download_file(zip_url, tmp_zip)
    except Exception as e: return f"Не удалось скачать архив: {e}"
    if sha:
        got = sha256_file(tmp_zip)
        if got.lower() != sha.lower():
            os.remove(tmp_zip); return "Проверка целостности провалена (sha256 не совпал)"
    backup = backup_current(root); apply_zip_over(root, tmp_zip)
    try: os.remove(tmp_zip)
    except: pass
    return f"Обновление установлено: {local_ver} → {remote_ver}\nБэкап: {backup}\n{notes}"
