import tkinter as tk
from tkinter import filedialog, messagebox
from tools.excel_tools import transform_excel
from updater import update_from_manifest, backup_current, apply_zip_over
import os
from dotenv import load_dotenv
import requests

def read_version():
    try:
        with open(os.path.join(os.path.abspath(os.path.dirname(__file__)), "VERSION"), "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return "unknown"

def select_file():
    path = filedialog.askopenfilename(title="Выберите Excel файл", filetypes=[("Excel files","*.xlsx *.xls")])
    if path:
        entry_file.delete(0, tk.END); entry_file.insert(0, path)

def run_agent():
    infile = entry_file.get().strip()
    if not infile or not os.path.exists(infile):
        messagebox.showerror("Ошибка","Выберите корректный Excel файл."); return
    base, ext = os.path.splitext(infile); outfile = base + "_out.xlsx"
    try:
        transform_excel(infile, outfile)
        messagebox.showinfo("Готово", f"Результат сохранён:\n{outfile}")
    except Exception as e:
        messagebox.showerror("Ошибка выполнения", str(e))

def do_update_online():
    root_dir = os.path.abspath(os.path.dirname(__file__))
    try:
        msg = update_from_manifest(root_dir)
        messagebox.showinfo("Обновление", msg)
    except Exception as e:
        messagebox.showerror("Ошибка обновления", str(e))

def do_update_from_zip():
    root_dir = os.path.abspath(os.path.dirname(__file__))
    zip_path = filedialog.askopenfilename(title="Выберите архив обновления (.zip)", filetypes=[("Zip files","*.zip")])
    if not zip_path: return
    try:
        backup = backup_current(root_dir)
        apply_zip_over(root_dir, zip_path)
        messagebox.showinfo("Обновление", f"Локальное обновление установлено. Бэкап: {backup}")
    except Exception as e:
        messagebox.showerror("Ошибка обновления", str(e))

def show_whats_new():
    load_dotenv()
    url = os.getenv("UPDATE_MANIFEST_URL","").strip()
    if not url:
        messagebox.showinfo("Что нового", "UPDATE_MANIFEST_URL не задан в .env")
        return
    try:
        r = requests.get(url, timeout=15)
        r.raise_for_status()
        m = r.json()
        remote_ver = str(m.get("version","")).strip()
        notes = str(m.get("notes","(нет заметок)"))
        messagebox.showinfo("Что нового", f"Версия: {remote_ver}\n\n{notes}")
    except Exception as e:
        messagebox.showerror("Ошибка", f"Не удалось получить манифест: {e}")

root = tk.Tk()
root.title(f"AI Excel Agent (Hybrid GPT-4) — v{read_version()}")
root.geometry("580x230")

frame = tk.Frame(root, padx=12, pady=12); frame.pack(fill="both", expand=True)

row1 = tk.Frame(frame); row1.pack(fill="x", pady=(0,8))
tk.Button(row1, text="Выбрать Excel", width=18, command=select_file).pack(side="left")
entry_file = tk.Entry(row1); entry_file.pack(side="left", fill="x", expand=True, padx=(8,0))

tk.Button(frame, text="Запустить агента", command=run_agent).pack(fill="x")
tk.Label(frame, text="Агент добавит столбец 'Sum' и сохранит *_out.xlsx").pack(anchor="w", pady=(8,6))

row2 = tk.Frame(frame); row2.pack(fill="x")
tk.Button(row2, text="Обновить из интернета ⤓", command=do_update_online).pack(side="left", fill="x", expand=True, padx=(0,6))
tk.Button(row2, text="Обновить из ZIP…", command=do_update_from_zip).pack(side="left", fill="x", expand=True, padx=(0,6))
tk.Button(row2, text="Что нового…", command=show_whats_new).pack(side="left")

root.mainloop()
